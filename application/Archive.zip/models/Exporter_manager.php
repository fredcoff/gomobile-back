<?php
/**
 * Created by IntelliJ IDEA.
 * User: xiong
 * Date: 2019/6/11
 * Time: 5:42 PM
 */


class Exporter_manager extends CI_Model {


	var  $gradeColorDatas = [
	'#000000',
	'#554012',
	'#aa7f23',
	'#ffbf35',
	'#ffffff',
	'#ffffff',
	'#ffffff',
	'#ffffff',
	'#aaec9d',
	'#55df4e',
	'#00d200',
	'#009155',
	'#004faa',
	'#000eff',
	'#000eff',
	'#000eff',
	];
	var $colorDatas = array(
	'000000',
	'0c0003',
	'180005',
	'240008',
	'31000b',
	'3d000d',
	'490010',
	'550013',
	'610015',
	'6d0018',
	'79001b',
	'86001d',
	'920020',
	'9e0023',
	'aa0025',
	'b60028',
	'c2002b',
	'ce002d',
	'db0030',
	'e70033',
	'f30035',
	'ff0038',
	'f4070e',
	'e9091a',
	'de0c26',
	'd30f32',
	'c8113e',
	'bd144a',
	'b21756',
	'a71962',
	'9c1c6e',
	'911f7a',
	'862187',
	'7b2493',
	'70279f',
	'6529ab',
	'5a2cb7',
	'4f2fc3',
	'4431cf',
	'3934db',
	'2e37e7',
	'2339f3',
	'183cff',
	'101bff',
	'0f26f5',
	'0e31eb',
	'0e3ce1',
	'0d46d7',
	'0c51cd',
	'0b5cc4',
	'0b67ba',
	'0a72b0',
	'097da6',
	'08889c',
	'089292',
	'079d88',
	'06a87e',
	'05b374',
	'05be6a',
	'04c961',
	'03d457',
	'02de4d',
	'02e943',
	'01f439',
	'00ff2f',
	);


	var $blackspotColors = [[['000000', '800080'], ['008000', '0000ff']], [['FFA500', 'ff0000'], ['FFFF00', 'ffffff']]];

	public function strength_kml($result, $kmlOption = array('type' => 0, 'blackspot' => 0) ,
								 $lineOption = array('stroke' => 8, 'transparency' => 0.8)) {

		// write xml header
		echo '<?xml version="1.0" encoding="UTF-8"?>';
		echo '<kml xmlns="http://earth.google.com/kml/2.0"> <Document>';

		$previousItem = null;
		$previousPoint = null;
		$type = $kmlOption['type'];

		if ($type >= 1) {
			$this->writeNPTIconHeader();

		}

		foreach($result as $item) {

			$test_result = json_decode($item['test_result'], true);
			$point = array(
				'lat' => $test_result['nLatitude'],
				'lng' => $test_result['nLongitude'],
			);

			$storePrevious = true;

			if ($type >= 1) {
				if ($type == 1)
					$nLatency = $this->getPingGrade($test_result['nLatency']);
				else
					$nLatency = $test_result['nLatency'];
				echo "<Placemark><name /><description><![CDATA[111]]></description><styleUrl>#signalLevel{$nLatency}</styleUrl><Point><coordinates>{$point['lng']},{$point['lat']},0.</coordinates></Point></Placemark>";

				continue;
			}

			if ($previousPoint) {

				$isConnectable = false;
				$diff_distance = $this->point_distance_kilometer($previousPoint, $point);

				if ($type == 0) {
					if ($item['batch_no'] > 0 && $item['batch_no'] == $previousItem['batch_no']) { // same batch no
						if ($diff_distance < 0.5) {
							$isConnectable = true;
						} else {
							$storePrevious = false;
						}
					} else if ($item['batch_no'] == 0 && $diff_distance < 0.1) {
						$isConnectable = true;
					}
				}

				if ($isConnectable) {
					$connLineOption = $lineOption;
					$connLineOption['color'] = $this->getLineColor($previousItem, $item, $kmlOption);
					$this->connect_point_strength_kml($previousPoint, $point, $connLineOption);
				}
			}

			if ($storePrevious) {
				$previousItem = $item;
				$previousPoint = $point;
			}
		}


		// write footer
		echo '</Document> </kml>';
	}

	private function getPingGrade($latency) {
		$nGrade = 0;
		if ($latency <= 0) {
			$nGrade = 0;
		} else if ($latency >= 2000) {
			$nGrade = 1;
		} else if ($latency >= 1500) {
			$nGrade = 2;
		} else if ($latency >= 1200) {
			$nGrade = 3;
		} else if ($latency >= 1000) {
			$nGrade = 4;
		} else if ($latency >= 800) {
			$nGrade = 5;
		} else if ($latency >= 600) {
			$nGrade = 6;
		} else if ($latency >= 500) {
			$nGrade = 7;
		} else if ($latency >= 300) {
			$nGrade = 8;
		} else if ($latency >= 200) {
			$nGrade = 9;
		} else if ($latency >= 100) {
			$nGrade = 10;
		} else if ($latency >= 75) {
			$nGrade = 11;
		} else if ($latency >= 50) {
			$nGrade = 12;
		} else if ($latency >= 30) {
			$nGrade = 13;
		} else if ($latency >= 20) {
			$nGrade = 14;
		} else {
			$nGrade = 15;
		}
		return $nGrade;
	}

	private function writeNPTIconHeader() {
		echo
		'<Style id="signalLevel0"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|0|464646|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel1"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|1|5F4646|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel2"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|2|794646|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel3"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|3|924646|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel4"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|4|AC4646|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel5"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|5|C54646|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel6"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|6|DF4646|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel7"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|7|F84646|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel8"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|8|FF4646|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel9"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|9|FF4646|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel10"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|10|FF4646|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel11"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|11|46465F|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel12"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|12|464679|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel13"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|13|464692|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel14"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|14|4646AC|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel15"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|15|4646C5|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel16"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|16|4646DF|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel17"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|17|4646F8|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel18"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|18|4646FF|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel19"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|19|4646FF|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel20"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|20|4646FF|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel21"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|21|465D46|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel22"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|22|467446|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel23"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|23|468B46|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel24"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|24|46A246|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel25"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|25|46B946|FFFFFF|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel26"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|26|46D146|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel27"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|27|46E846|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel28"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|28|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel29"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|29|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel30"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|30|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel31"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|31|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel32"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|32|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel33"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|33|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel34"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|34|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel35"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|35|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel36"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|36|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel37"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|37|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel38"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|38|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel39"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|39|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel40"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|40|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel41"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|41|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel42"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|42|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel43"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|43|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel44"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|44|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel45"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|45|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel46"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|46|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel47"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|47|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel48"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|48|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel49"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|49|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel50"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|50|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel51"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|51|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel52"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|52|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel53"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|53|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel54"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|54|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel55"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|55|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel56"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|56|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel57"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|57|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel58"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|58|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel59"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|59|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel60"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|60|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel61"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|61|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel62"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|62|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style><Style id="signalLevel63"><IconStyle><Icon><href>http://www.google.com/chart?chst=d_map_xpin_letter&amp;chld=pin_star|63|46FF46|000000|0000FF</href></Icon></IconStyle><BalloonStyle><text>$[description]</text></BalloonStyle></Style>'
		;
	}

	private function getLineColor($prevItem, $currItem, $kmlOption) {
		$type = $kmlOption['type'];
		$blackspot = $kmlOption['blackspot'];
		if ($type == 0) {
			if ($blackspot > 0) {
				$telstra_flag = 1;
				if ($prevItem['telstra_ss'] <= 3) {
					$telstra_flag = 0;
				}
				$vodafone_flag = 1;
				if ($prevItem['vodafone_ss'] <= 3) {
					$vodafone_flag = 0;
				}
				$optus_flag = 1;
				if ($prevItem['optus_ss'] <= 3) {
					$optus_flag = 0;
				}

				echo 'here';
        		return $this->blackspotColors[$telstra_flag][$vodafone_flag][$optus_flag];
      		} else {
				$prevSSVal = $prevItem['ss_val'];
				$nextSSVal = $currItem['ss_val'];
				$colorStep = floor((floatval($prevSSVal) + floatval($nextSSVal)) / 2);
				if ($colorStep < 0) {
					$colorStep = 0;
				} else if ($colorStep > 63) {
					$colorStep = 63;
				}
				// echo "---$colorStep---";
        		return $this->colorDatas[$colorStep];
      		}
		} else if ($type == 1 || $type == 2 || $type == 3) {
			$prevTestResultData = json_decode($prevItem['test_result'], true);
			$nextTestResultData = json_decode($currItem['test_result'], true);

			$prevGrade = $this->getItemGrade($prevTestResultData);
			$nextGrade = $this->getItemGrade($nextTestResultData);

			$avgGrade = floor(($prevGrade + $nextGrade) / 2);

			return $this->gradeColorDatas[$avgGrade];
		}
	}

	private function getItemGrade($resultData) {
		return 1;
	}
	private function getKMLColor($htmlColor) {
		return substr($htmlColor, 4, 2).substr($htmlColor, 2, 2).substr($htmlColor, 0, 2);
	}

	public function connect_point_strength_kml($prevPt, $currPt, $strokeOption =
		array('stroke' => 8, 'transparency' => 0.8, 'color' => '#9e0023')) {

		$transVal = dechex(floor($strokeOption['transparency'] * 255));
		$transVal = str_pad($transVal, 2, "0", STR_PAD_LEFT);

		$colorVal = $transVal.$this->getKMLColor($strokeOption['color']);

		// echo $colorVal;
		echo "<Placemark>";
		echo "<LineString>";
        echo "    <coordinates>".PHP_EOL;
		echo "{$prevPt['lng']},{$prevPt['lat']},0".PHP_EOL;
		echo "{$currPt['lng']},{$currPt['lat']},0".PHP_EOL;
		echo "</coordinates>";
        // echo "    <altitudeMode>absolute</altitudeMode>";
        echo "</LineString>";
        echo "<Style>";
        echo "    <LineStyle>";
        echo "        <color>{$colorVal}</color>";
        echo "        <width>{$strokeOption['stroke']}</width>";
        echo "    </LineStyle>";
        echo "</Style>";
    	echo "</Placemark>";

		return;

	}

	private function point_distance_kilometer($prevPt, $currPt) {
		return $this->vincentyGreatCircleDistance($prevPt['lat'], $prevPt['lng'], $currPt['lat'], $currPt['lng']) / 1000.0;
	}

	/**
	 * https://stackoverflow.com/questions/10053358/measuring-the-distance-between-two-coordinates-in-php
	 *
	 * Calculates the great-circle distance between two points, with
	 * the Vincenty formula.
	 * @param float $latitudeFrom Latitude of start point in [deg decimal]
	 * @param float $longitudeFrom Longitude of start point in [deg decimal]
	 * @param float $latitudeTo Latitude of target point in [deg decimal]
	 * @param float $longitudeTo Longitude of target point in [deg decimal]
	 * @param float $earthRadius Mean earth radius in [m]
	 * @return float Distance between points in [m] (same as earthRadius)
	 */
	public  function vincentyGreatCircleDistance(
		$latitudeFrom, $longitudeFrom, $latitudeTo, $longitudeTo, $earthRadius = 6371000)
	{
		// convert from degrees to radians
		$latFrom = deg2rad($latitudeFrom);
		$lonFrom = deg2rad($longitudeFrom);
		$latTo = deg2rad($latitudeTo);
		$lonTo = deg2rad($longitudeTo);

		$lonDelta = $lonTo - $lonFrom;
		$a = pow(cos($latTo) * sin($lonDelta), 2) +
			pow(cos($latFrom) * sin($latTo) - sin($latFrom) * cos($latTo) * cos($lonDelta), 2);
		$b = sin($latFrom) * sin($latTo) + cos($latFrom) * cos($latTo) * cos($lonDelta);

		$angle = atan2(sqrt($a), $b);
		return $angle * $earthRadius;
	}
}
