<?php
namespace MatthiasMullie\Geo;

/**
 * @author Matthias Mullie <geo@mullie.eu>
 */
class Exception extends \Exception
{
}
