<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Data extends BD_Controller {
    function __construct()
    {
        // Construct the parent class
        parent::__construct();
        $this->auth();
    }

    public function result_get()
	{
        // $theCredential = $this->user_data;

        $this->load->model('test_manager');

        $type = $this->get('type');

        $criteria = array(
            'type' => $type
		);

        $start_date = $this->get('dateStart');
		$end_date = $this->get('dateEnd');
        $hour = $this->get('hour');
		$commType = $this->get('commType');
		$carrier = $this->get('carrier');
		$geofencingId = $this->get('geofencingId');
		$blackspot = $this->get('blackspot');

        if ($start_date) {
            $date_pared = date_parse($start_date);
			$date_str = sprintf('%04d-%02d-%02d', $date_pared['year'],
				$date_pared['month'], $date_pared['day']);

            $criteria['start_date'] = $date_str;
        } else {
			$criteria['start_date'] = date('Y-m-d');
		}

		if ($end_date) {
			$date_pared = date_parse($end_date);
			$date_str = sprintf('%04d-%02d-%02d', $date_pared['year'],
				$date_pared['month'], $date_pared['day']);

			$criteria['end_date'] = $date_str;
		} else {
			$criteria['end_date'] = date('Y-m-d');
		}

        if ($hour >= 0 && $hour <= 24) {
        	$criteria['hour'] = $hour;
		} else {
			$criteria['hour'] = -1;
		}

		if ($commType != '' && $commType != -1) {
			$criteria['is_lte'] = ($commType == 1)?1:0;
		}

		if ($carrier && $carrier != '-1') {
			$criteria['carrier'] = $carrier;
		}

		if ($geofencingId && $geofencingId != '-1') {
			$criteria['geofencingId'] = $geofencingId;
		}

		if ($blackspot) {
			$criteria['blackspot'] = 1;
		} else {
			$criteria['blackspot'] = 0;
		}



        $result = $this->test_manager->get_test_data($criteria);

		if ($this->get('kml')) {
			$this->load->model('exporter_manager');

			$kmlOption = array(
				'type' => $criteria['type'],
				'blackspot' => $criteria['blackspot']
			);

			$lineOption = array(
				'stroke' => 8,
				'transparency' => 0.8
			);

			if ($this->get('stroke')) {
				$lineOption['stroke'] = $this->get('stroke');
			}
			if ($this->get('transparency')) {
				$lineOption['transparency'] = $this->get('transparency');
			}

			$fileName = "download.kml";
			header('Content-Type: text/xml');
			header('Content-Disposition: attachment; filename="' . $fileName . '"');

			ob_start();
			$this->exporter_manager->strength_kml($result, $kmlOption, $lineOption);
			ob_end_flush();

		} else {
			$knn_result_and_stats = $this->test_manager->knn_line($result, $criteria);
			$return_result = array('markers' => $result,
				'lines' => $knn_result_and_stats['dots'],
				'stats' => $knn_result_and_stats['stats']);
			$this->response($return_result, 200);
		}
    }

	public function result_delete()
	{
		$idx = $this->input->get('idx');
		$this->test_manager->delete_test_data_by_idx($idx);
		$this->response(array(), 200);
		// echo 'hello';
	}

	public function fencing_list_get()
	{
		$fencing_list = $this->test_manager->get_fencing_list();
		$this->response(array('fencing_list' => $fencing_list), 200);
	}

	public function fencing_get($fencing_id)
	{
		$fencing = $this->test_manager->get_fencing_by_id($fencing_id);
		$this->response(array('fencing' => $fencing), 200);
	}

	public function fencing_delete($fencing_id)
	{
		$this->test_manager->delete_fencing_by_id($fencing_id);
		$this->response(array('success' => true), 200);
	}

	public function fencing_post()
	{
		/*
		$fencing = array(
			'title' => 'title 1',
			'polygon' => array(
				array('lat' => 0, 'lng' => 0),
				array('lat' => 90, 'lng' => 0),
				array('lat' => 90, 'lng' => 90),
			)
		);
		*/
		$fencing = $this->post('fencing');

		$last_id = $this->test_manager->insert_fencing($fencing);
		$this->response(array('last_id' => $last_id), 200);
	}

	public function fencing_put($fencing_id)
	{
		$fencing = $this->put('fencing');
		$fencing['id'] = $fencing_id;
		$this->test_manager->update_fencing($fencing);
		$this->response(array('success' => true), 200);
	}

	public function dashboard_get(){
    	$this->load->model('test_manager');

    	$total_ss = $this->test_manager->get_stats_ss();
		$total_ss_spot = $this->test_manager->get_stats_ss_blackspot();
		$total_npt = $this->test_manager->get_stats_npt();

    	$dashboard_statistic = array(
    		array('title' => 'Number of Signal Strength markers', 'text' => number_format($total_ss['total_count']), 'value' => $total_ss['total_count']),
			array('title' => 'Number of black spot markers', 'text' => number_format($total_ss_spot['total_count']), 'value' => $total_ss_spot['total_count']),
			array('title' => 'Klms of black spots', 'text' => number_format($total_ss_spot['total_distance']/ 1000, 2).'km', 'value' => $total_ss_spot['total_distance']),
			array('title' => 'Total distance tested', 'text' => number_format($total_ss['total_distance']/ 1000, 2).'km', 'value' => $total_ss['total_distance']),
			array('title' => 'Number of Network Performance Tests', 'text' => number_format($total_npt['total_count']), 'value' => $total_npt['total_count']),
			array('title' => 'Highest speed download', 'text' => '64Mbps', 'value' => '100'),
			array('title' => 'Highest upload speed', 'text' => '9.0Mbps', 'value' => '100'),
			array('title' => 'Time to the internet and back (latency - lower is better)', 'text' => '56ms', 'value' => '56'),
		);
		$this->response($dashboard_statistic, 200);
	}
}
